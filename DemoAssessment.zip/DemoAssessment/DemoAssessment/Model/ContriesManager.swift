//
//  ContriesManager.swift
//  DemoAssessment
//
//  Created by naeem alabboodi on 7/25/23.
//

import UIKit

struct ContriesManager {
    
    
    func fetchCountries(completion: @escaping ([Country]) -> Void) {
        let urlString = "https://gist.githubusercontent.com/peymano-wmt/32dcb892b06648910ddd40406e37fdab/raw/db25946fd77c5873b0303b858e861ce724e0dcd0/countries.json"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, _, error) in
            if let error = error {
                print("Failed to fetch data:", error)
                return
            }
            
            guard let data = data else { return }
            
            do {
                let countries = try JSONDecoder().decode([Country].self, from: data)
                DispatchQueue.main.async {
                    completion(countries)
                }
            } catch let jsonError {
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
}
