//
//  ViewController.swift
//  DemoAssessment
//
//  Created by naeem alabboodi on 7/25/23.
//

import UIKit

class ViewController: UITableViewController, UISearchResultsUpdating {
    
    var countries: [Country] = []
    let searchController = UISearchController(searchResultsController: nil) // Create a UISearchController
    var filteredCountries: [Country] = [] // This will hold your search results
   
    override func viewDidLoad() {
        super.viewDidLoad()
        Configer()
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "MainCell")
        let coutrieManager = ContriesManager()
        coutrieManager.fetchCountries { items in
            self.countries = items
            DispatchQueue.main.async {
                self.updateSearchResults(for: self.searchController) // Call it here
                self.tableView.reloadData()
            }
        }
    }
    

    
    func Configer() {
        tableView.backgroundColor = .cyan
        navigationItem.title = "List of Contries "
        
        // Configure UISearchController
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Countries"
        navigationItem.searchController = searchController
        definesPresentationContext = true
      
        
    }
    
    // Implement the method from UISearchResultsUpdating
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text, !searchText.isEmpty {
            filteredCountries = countries.filter { country in
                return country.name.lowercased().contains(searchText.lowercased()) ||
                country.capital.lowercased().contains(searchText.lowercased())
            }
        } else {
            filteredCountries = countries
            tableView.reloadData()
        }
        tableView.reloadData()
    }
    
    
    
}

extension ViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredCountries.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainCell", for: indexPath) as! TableViewCell
        let country = filteredCountries[indexPath.row]
        cell.nameLabel.text = country.name
        cell.capitalLabel.text = country.capital
        cell.regionLabel.text = "\(country.region)"
        cell.languageLabel.text = "\(country.language)"
        
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let country = filteredCountries[indexPath.row]
        let detailVC = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.country = country
        searchController.isActive = false
        navigationController?.pushViewController(detailVC, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vcDestination = segue.destination as! DetailViewController
        if  let indexPath = tableView.indexPathForSelectedRow {
            vcDestination.selectedDetails = countries[indexPath.row]
        }
    }
}



