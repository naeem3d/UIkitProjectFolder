//
//  DetailViewController.swift
//  DemoAssessment
//
//  Created by naeem alabboodi on 7/26/23.
//

import UIKit

class DetailViewController: UIViewController {
    var  selectedDetails: Country? {
        didSet {
          
        }
    }
    var country: Country?
    @IBOutlet weak var nameLabel: UILabel!
        @IBOutlet weak var capitalLabel: UILabel!
        @IBOutlet weak var regionLabel: UILabel!
        @IBOutlet weak var languageLabel: UILabel!

        override func viewDidLoad() {
            super.viewDidLoad()

            nameLabel.text = country?.name
            capitalLabel.text = country?.capital
            regionLabel.text = country?.region.rawValue
            languageLabel.text = country?.language.name
        }


}
